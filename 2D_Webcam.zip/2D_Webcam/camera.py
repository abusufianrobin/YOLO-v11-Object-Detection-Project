import cv2
import time
import os

class VideoCamera:
    def __init__(self, src=0):
        self.cap = cv2.VideoCapture(src)

    def get_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            return None
        ret, jpeg = cv2.imencode('.jpg', frame)
        return jpeg.tobytes()

    def capture_image(self, save_dir):
        ret, frame = self.cap.read()
        if not ret:
            return None, None
        filename = os.path.join(save_dir, f"capture_{int(time.time())}.jpg")
        cv2.imwrite(filename, frame)
        return frame, filename
