import cv2
import numpy as np
from ultralytics import YOLO

# --------------------------- CONFIG ---------------------------
MODEL_PATH = "best.pt"
DISTANCE = 50.0   # Distance to object in cm (for width/height calculation)
FOCAL = 800.0     # Camera focal length in pixels
CONF_THRESH = 0.4 # Confidence threshold

# Load YOLO model
model = YOLO(MODEL_PATH)
labels = model.names

# Bounding box colors
bbox_colors = [(164,120,87), (68,148,228), (93,97,209), (178,182,133),
               (88,159,106), (96,202,231), (159,124,168), (169,162,241),
               (98,118,150), (172,176,184)]

# --------------------------- FUNCTION ---------------------------
def run_object_detection(frame):
    """
    Run YOLO detection on a frame.
    Returns:
        detection_img : frame with overlay
        object_count  : int
        fps           : float
        detections    : list of dict {class, conf, width_cm, height_cm, color}
    """
    import time
    t_start = time.perf_counter()

    results = model(frame, verbose=False)
    detections = results[0].boxes

    object_count = 0
    det_list = []

    for det in detections:
        conf = det.conf.item()
        if conf < CONF_THRESH:
            continue

        xmin, ymin, xmax, ymax = det.xyxy[0].cpu().numpy().astype(int)
        class_id = int(det.cls.item())
        label = labels[class_id]
        color = bbox_colors[class_id % len(bbox_colors)]

        # Draw bounding box
        cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), color, 2)
        label_text = f"{label}: {conf:.2f}"
        cv2.putText(frame, label_text, (xmin, ymin-5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 1)

        # Compute width & height in cm
        w_px, h_px = xmax - xmin, ymax - ymin
        w_cm = w_px * DISTANCE / FOCAL
        h_cm = h_px * DISTANCE / FOCAL
        cv2.putText(frame, f"W:{w_cm:.1f}cm H:{h_cm:.1f}cm", (xmin, ymax+15),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)

        object_count += 1

        det_list.append({
            "class": label,
            "conf": round(conf, 2),
            "width_cm": round(w_cm, 2),
            "height_cm": round(h_cm, 2),
            "color": color
        })

    fps = 1.0 / (time.perf_counter() - t_start)

    return frame, object_count, round(fps, 2), det_list
