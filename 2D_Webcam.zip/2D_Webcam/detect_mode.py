from ultralytics import YOLO
import cv2
import numpy as np
import time

# Load your existing YOLO model (same as model.py)
MODEL_PATH = "best.pt"
model = YOLO(MODEL_PATH, task='detect')
labels = model.names

# Color palette for bounding boxes
bbox_colors = [(164,120,87), (68,148,228), (93,97,209), (178,182,133),
               (88,159,106), (96,202,231), (159,124,168), (169,162,241),
               (98,118,150), (172,176,184)]

# Default camera parameters
DEFAULT_DISTANCE = 50.0  # cm
DEFAULT_FOCAL = 800.0    # pixels
CONF_THRESH = 0.4

def run_object_detection(frame, distance=DEFAULT_DISTANCE, focal=DEFAULT_FOCAL, conf_thresh=CONF_THRESH):
    """
    Run YOLO detection + classification + width/height measurement on a single frame.
    Returns:
        frame: annotated frame (BGR)
        object_count: number of detected objects
        fps: inference FPS
        detections_list: list of detected objects with size & label
    """
    t_start = time.perf_counter()
    results = model(frame, verbose=False)
    detections = results[0].boxes

    object_count = 0
    detections_list = []

    for i, det in enumerate(detections):
        conf = det.conf.item()
        if conf < conf_thresh:
            continue

        xmin, ymin, xmax, ymax = det.xyxy[0].cpu().numpy().astype(int)
        class_id = int(det.cls.item())
        label = labels[class_id]
        color = bbox_colors[class_id % len(bbox_colors)]

        # Draw bounding box & label
        cv2.rectangle(frame, (xmin,ymin), (xmax,ymax), color, 2)
        cv2.putText(frame, f"{label}: {conf:.2f}", (xmin, ymin-5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 1)

        # Compute width & height in cm
        w_px, h_px = xmax-xmin, ymax-ymin
        w_cm = w_px * distance / focal
        h_cm = h_px * distance / focal
        cv2.putText(frame, f"W:{w_cm:.1f}cm H:{h_cm:.1f}cm", (xmin, ymax+15),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)

        object_count += 1

        detections_list.append({
            "class": label,
            "conf": round(conf,2),
            "width_cm": round(w_cm,1),
            "height_cm": round(h_cm,1),
            "bbox": [int(xmin), int(ymin), int(xmax), int(ymax)],
            "color": color
        })

    fps = 1.0 / (time.perf_counter() - t_start)
    return frame, object_count, fps, detections_list
