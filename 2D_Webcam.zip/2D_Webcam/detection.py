from ultralytics import YOLO
import cv2
import numpy as np
from utils import compute_distance, grid_to_world, draw_grid_background

# ---------------- CONFIG ----------------
MODEL_PATH = "best_2D.pt"
MAP_SIZE = 500
RESOLUTION = 0.05  # meters per pixel

# BOT location (bottom-right corner)
BOT_CORNER = (MAP_SIZE - 20, MAP_SIZE - 20)

# ---------------- LOAD MODEL ----------------
model = YOLO(MODEL_PATH)

# 🔒 HARD-LOCKED CLASS IDS
FIRE_CLASS_ID = 0
SMOKE_CLASS_ID = 1   # ❌ COMPLETELY IGNORED
PERSON_CLASS_ID = 2

# COLORS
PERSON_COLOR = (0, 255, 0)   # Green
FIRE_COLOR   = (0, 165, 255) # Orange
BOT_COLOR    = (0, 0, 255)   # Red


def process_image(frame, img_filename, map_dir):
    results = model(frame, verbose=False)

    occupancy_map = draw_grid_background(MAP_SIZE)
    measurements = []

    # ---------------- DETECTION LOOP ----------------
    for r in results:
        for box in r.boxes:
            cls_id = int(box.cls[0])
            conf = float(box.conf[0])

            # ❌ IGNORE SMOKE COMPLETELY
            if cls_id == SMOKE_CLASS_ID:
                continue

            x1, y1, x2, y2 = map(int, box.xyxy[0])
            cx, cy = (x1 + x2) // 2, (y1 + y2) // 2

            # ---------------- PERSON ----------------
            if cls_id == PERSON_CLASS_ID:
                label = f"PERSON {conf:.2f}"

                cv2.rectangle(frame, (x1, y1), (x2, y2), PERSON_COLOR, 2)
                cv2.putText(
                    frame, label, (x1, y1 - 8),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                    PERSON_COLOR, 2, cv2.LINE_AA
                )

                # Distance calculation
                dist_to_bot = compute_distance((cx, cy), BOT_CORNER, RESOLUTION)
                wx, wy = grid_to_world((cx, cy), RESOLUTION)

                measurements.append({
                    "class": "person",
                    "x": round(wx, 2),
                    "y": round(wy, 2),
                    "distance_to_bot": round(dist_to_bot, 2),
                    "centroid": (cx, cy),
                    "color": PERSON_COLOR
                })

                # Draw on map
                cv2.circle(occupancy_map, (cx, cy), 6, PERSON_COLOR, -1)
                cv2.line(occupancy_map, BOT_CORNER, (cx, cy), PERSON_COLOR, 2)

                cv2.putText(
                    occupancy_map,
                    f"{dist_to_bot:.2f} m",
                    (cx + 5, cy - 5),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    PERSON_COLOR,
                    2,
                    cv2.LINE_AA
                )

            # ---------------- FIRE ----------------
            elif cls_id == FIRE_CLASS_ID:
                label = f"FIRE {conf:.2f}"

                cv2.rectangle(frame, (x1, y1), (x2, y2), FIRE_COLOR, 2)
                cv2.putText(
                    frame, label, (x1, y1 - 8),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                    FIRE_COLOR, 2, cv2.LINE_AA
                )

    # ---------------- DRAW BOT ----------------
    cv2.rectangle(
        occupancy_map,
        (BOT_CORNER[0] - 12, BOT_CORNER[1] - 12),
        (BOT_CORNER[0] + 12, BOT_CORNER[1] + 12),
        BOT_COLOR,
        -1
    )

    cv2.putText(
        occupancy_map,
        "BOT",
        (BOT_CORNER[0] - 40, BOT_CORNER[1] - 15),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        BOT_COLOR,
        2,
        cv2.LINE_AA
    )

    # ---------------- SAVE MAP ----------------
    map_filename = img_filename.replace(
        "captures", "maps"
    ).replace(".jpg", "_map.jpg")

    cv2.imwrite(map_filename, occupancy_map)

    return map_filename, measurements
