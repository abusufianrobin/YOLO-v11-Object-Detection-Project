from ultralytics import YOLO
import cv2
import numpy as np
from utils import cluster_occupancy_grid, compute_distance, grid_to_world, draw_grid_background

# ---------------- CONFIG ----------------
MODEL_PATH = "best_2D.pt"
MAP_SIZE = 500
RESOLUTION = 0.05  # meters per pixel

# BOT location (bottom-right corner)
BOT_CORNER = (MAP_SIZE - 20, MAP_SIZE - 20)

# Load YOLOv8n model
model = YOLO(MODEL_PATH)
CLASS_NAMES = model.names

# Ensure CLASS_NAMES is a list
if isinstance(CLASS_NAMES, dict):
    CLASS_NAMES = [CLASS_NAMES[k] for k in sorted(CLASS_NAMES.keys())]

# Object colors for frame annotations and map
OBJECT_COLORS = {
    "fire": (0, 0, 255),      # Red
    "smoke": (128, 128, 128), # Gray
    "person": (0, 255, 0),    # Green
    "unknown": (255, 255, 255)
}

def process_image(frame, img_filename, map_dir):
    # Run YOLOv8 inference
    results = model(frame, verbose=False)

    # Create grid background
    occupancy_map = draw_grid_background(MAP_SIZE)
    detections_list = []

    # ---------------- Detect objects and annotate frame ----------------
    for r in results:
        for box in r.boxes:
            cls_id = int(box.cls[0])
            conf = float(box.conf[0])
            x1, y1, x2, y2 = map(int, box.xyxy[0])

            class_name = CLASS_NAMES[cls_id].lower()
            color = OBJECT_COLORS.get(class_name, OBJECT_COLORS["unknown"])

            # Draw bounding box on captured frame (not occupancy map)
            label = f"{class_name.upper()} {conf:.2f}"
            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            cv2.rectangle(frame, (x1, y1-th-10), (x1+tw+6, y1), color, -1)
            cv2.putText(frame, label, (x1+3, y1-5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2, cv2.LINE_AA)

            # Save for clustering and distance computation
            cx, cy = (x1 + x2)//2, (y1 + y2)//2
            detections_list.append({
                "class": class_name,
                "centroid": (cx, cy),
                "color": color
            })

    # ---------------- Draw BOT location ----------------
    cv2.rectangle(occupancy_map,
                  (BOT_CORNER[0]-12, BOT_CORNER[1]-12),
                  (BOT_CORNER[0]+12, BOT_CORNER[1]+12),
                  (0, 0, 0), -1)
    cv2.putText(occupancy_map, "BOT", (BOT_CORNER[0]-30, BOT_CORNER[1]-15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2, cv2.LINE_AA)

    measurements = []

    # ---------------- Draw detected objects ----------------
    for det in detections_list:
        cx, cy = det["centroid"]
        obj_class = det["class"]
        color = det["color"]

        # Distance to BOT
        dist_to_bot = compute_distance((cx, cy), BOT_CORNER, RESOLUTION)
        wx, wy = grid_to_world((cx, cy), RESOLUTION)

        measurements.append({
            "class": obj_class,
            "x": round(wx, 2),
            "y": round(wy, 2),
            "distance_to_bot": round(dist_to_bot, 2),
            "centroid": (cx, cy),
            "color": color
        })

        # Draw centroid
        cv2.circle(occupancy_map, (cx, cy), 6, color, -1)
        # Draw line to BOT
        cv2.line(occupancy_map, BOT_CORNER, (cx, cy), color, 3)
        # Annotate coordinates and distance (bold)
        text = f"{obj_class.upper()} ({wx:.2f}, {wy:.2f}) | {dist_to_bot:.2f} m"
        cv2.putText(occupancy_map, text, (cx+5, cy-5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2, cv2.LINE_AA)

    # ---------------- Inter-object distances ----------------
    for i in range(len(measurements)):
        for j in range(i+1, len(measurements)):
            c1 = measurements[i]["centroid"]
            c2 = measurements[j]["centroid"]
            dist = compute_distance(c1, c2, RESOLUTION)
            mid_pt = ((c1[0]+c2[0])//2, (c1[1]+c2[1])//2)
            # Line between objects
            cv2.line(occupancy_map, c1, c2, (255, 255, 0), 1)
            # Annotate distance
            cv2.putText(occupancy_map, f"{dist:.2f} m", (mid_pt[0]+3, mid_pt[1]-3),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 0), 2, cv2.LINE_AA)

    # ---------------- Save occupancy map ----------------
    map_filename = img_filename.replace("captures", "maps").replace(".jpg", "_map.jpg")
    cv2.imwrite(map_filename, occupancy_map)

    return map_filename, measurements
