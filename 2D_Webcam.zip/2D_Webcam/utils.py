import numpy as np
from sklearn.cluster import DBSCAN
import cv2

def create_occupancy_grid(occupancy_map, bbox, color):
    x1, y1, x2, y2 = bbox
    h, w = occupancy_map.shape[:2]
    mx1 = int(x1 * w / 1280)
    my1 = int(y1 * h / 720)
    mx2 = int(x2 * w / 1280)
    my2 = int(y2 * h / 720)
    occupancy_map[my1:my2, mx1:mx2] = color
    return occupancy_map

def cluster_occupancy_grid(occupancy_map, eps=5, min_samples=30):
    ys, xs = np.nonzero(np.sum(occupancy_map, axis=2))
    if len(xs) == 0:
        return []
    points = np.column_stack((xs, ys))
    clustering = DBSCAN(eps=eps, min_samples=min_samples).fit(points)
    labels = clustering.labels_
    clusters = []
    for cid in set(labels):
        if cid == -1:
            continue
        pts = points[labels == cid]
        centroid = pts.mean(axis=0)
        clusters.append({"points": pts, "centroid": tuple(centroid)})
    return clusters

def compute_distance(p1, p2, resolution):
    dx = (p1[0] - p2[0]) * resolution
    dy = (p1[1] - p2[1]) * resolution
    return np.sqrt(dx**2 + dy**2)

def grid_to_world(point, resolution):
    return (point[0]*resolution, point[1]*resolution)

def draw_grid_background(size, grid_spacing_px=25, major_spacing_px=100):
    img = np.ones((size, size, 3), dtype=np.uint8) * 240
    for i in range(0, size, grid_spacing_px):
        color = (200, 200, 200)
        thickness = 1
        if i % major_spacing_px == 0:
            color = (160, 160, 160)
            thickness = 2
        cv2.line(img, (i, 0), (i, size), color, thickness)
        cv2.line(img, (0, i), (size, i), color, thickness)
    return img
