from flask import Flask, render_template, Response, request, jsonify
from camera import VideoCamera
from detection import process_image
from model import run_object_detection
import cv2
import os
import numpy as np  
from flask import send_file


app = Flask(__name__)

camera = VideoCamera()
CAPTURE_DIR = "static/captures"
MAP_DIR = "static/maps"
DETECT_DIR = "static/detect"
os.makedirs(DETECT_DIR, exist_ok=True)

os.makedirs(CAPTURE_DIR, exist_ok=True)
os.makedirs(MAP_DIR, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

def gen_frames():
    while True:
        frame = camera.get_frame()
        if frame is None:
            continue
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/capture', methods=['POST'])
def capture():
    img, filename = camera.capture_image(CAPTURE_DIR)
    map_filename, measurements = process_image(img, filename, MAP_DIR)
    return jsonify({
        "image": filename,
        "map": map_filename,
        "measurements": measurements
    })

@app.route('/detect_mode', methods=['POST'])
def detect_mode():
    frame_bytes = camera.get_frame()
    if frame_bytes is None:
        return jsonify({"error": "Camera frame not available."})

    frame = cv2.imdecode(
        np.frombuffer(frame_bytes, np.uint8),
        cv2.IMREAD_COLOR
    )

    detection_img, object_count, fps, detections = run_object_detection(frame)

    tmp_path = os.path.join(DETECT_DIR, "detect_mode.jpg")
    cv2.imwrite(tmp_path, detection_img)

    return jsonify({
        "image": "/static/detect/detect_mode.jpg",
        "object_count": object_count,
        "fps": fps,
        "detections": detections
    })


@app.route('/download_detect', methods=['GET'])
def download_detect():
    file_path = os.path.join(CAPTURE_DIR, "detect_mode.jpg")
    if not os.path.exists(file_path):
        return jsonify({"error": "File not found"}), 404

    return send_file(
        file_path,
        as_attachment=True,
        download_name="object_detection_result.jpg"
    )


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
