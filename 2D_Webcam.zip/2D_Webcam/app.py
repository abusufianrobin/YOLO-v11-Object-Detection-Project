from flask import Flask, render_template, Response, request, jsonify
from camera import VideoCamera
from detection import process_image
from model import run_object_detection
import cv2
import os
import numpy as np  # <-- Add this line

app = Flask(__name__)

camera = VideoCamera()
CAPTURE_DIR = "static/captures"
MAP_DIR = "static/maps"
os.makedirs(CAPTURE_DIR, exist_ok=True)
os.makedirs(MAP_DIR, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

def gen_frames():
    while True:
        frame = camera.get_frame()
        if frame is None:
            continue
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/capture', methods=['POST'])
def capture():
    img, filename = camera.capture_image(CAPTURE_DIR)
    map_filename, measurements = process_image(img, filename, MAP_DIR)
    return jsonify({
        "image": filename,
        "map": map_filename,
        "measurements": measurements
    })

@app.route('/detect_mode', methods=['POST'])
def detect_mode():
    frame_bytes = camera.get_frame()
    if frame_bytes is None:
        return jsonify({"error": "Camera frame not available."})

    # Convert JPEG bytes to OpenCV BGR image
    frame = cv2.imdecode(np.frombuffer(frame_bytes, np.uint8), cv2.IMREAD_COLOR)

    # Run object detection mode
    detection_img, object_count, fps, detections = run_object_detection(frame)

    tmp_path = os.path.join(CAPTURE_DIR, "detect_mode.jpg")
    cv2.imwrite(tmp_path, detection_img)

    return jsonify({
        "image": tmp_path,
        "object_count": object_count,
        "fps": fps,
        "detections": detections
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
